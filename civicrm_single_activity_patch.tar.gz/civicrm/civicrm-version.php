<?php
/** @deprecated */
function civicrmVersion( ) {
  return array( 'version'  => '5.28.3',
                'cms'      => 'Drupal',
                'revision' => '' );
}

